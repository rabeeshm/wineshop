<?php
class Confianz_OpenERPConnector_Helper_Data extends Mage_Core_Helper_Abstract
{
    //Linux4ever_MagentoXtender_Model_Api
}
?>
