<?php
class Vinagento_Vpager_Block_Catalog_Product_List extends Mage_Catalog_Block_Product_List{
	protected function _prepareLayout(){
		//Mage::log($this->getRequest()->getParams());
		//die();
	}
}
