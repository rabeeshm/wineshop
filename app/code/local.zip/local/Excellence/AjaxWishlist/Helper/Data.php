<?php

class Excellence_AjaxWishlist_Helper_Data extends Mage_Core_Helper_Abstract
{

}