<?php

/**
 *
 * @author rabeesh@confianzit.biz 
 * @category    Wineshop
 * @package     Wineshop_Api
 */
class Wineshop_Taxes_Helper_Data extends Mage_Core_Helper_Abstract {
    
}

?>
