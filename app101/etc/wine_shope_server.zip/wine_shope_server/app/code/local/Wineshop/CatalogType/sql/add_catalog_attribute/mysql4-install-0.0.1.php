<?php
$this->startSetup();
$this->addAttribute('catalog_product', 'product_type', array(
    'group'         => 'General',
    'input'         => 'select',
    'type'          => 'varchar',
    'label'         => 'Product Type',
    'backend'       => '',
    'visible'       => true,
    'required'      => false,
    'visible_on_front' => false,
	'sort_order' =>     '6',
	'option' => array('values' => array('Wine', 'Packet')),
    'global'        => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_GLOBAL,
));
 
$this->endSetup();