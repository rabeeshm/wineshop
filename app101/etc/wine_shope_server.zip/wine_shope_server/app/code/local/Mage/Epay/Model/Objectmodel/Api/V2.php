<?php
class Mage_Epay_Model_Objectmodel_Api_V2 extends Mage_Epay_Model_Objectmodel_Api
{    
	
}