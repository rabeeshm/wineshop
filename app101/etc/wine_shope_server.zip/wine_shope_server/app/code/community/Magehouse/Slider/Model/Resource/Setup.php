<?php
	
class Magehouse_Slider_Model_Resource_Setup extends Mage_Core_Model_Resource_Setup {
	
}